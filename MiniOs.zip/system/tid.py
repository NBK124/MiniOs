import colorama

APPS = "СЕРВИСЫ"
CALC = "1. Калькуляторы"
CHOICE = "Чтобы открыть сервис, введите его номер: "
SHUTDOWN = 'Завершить сеанс (введите "exit")'
READY = colorama.Style.BRIGHT + "Чтобы продолжить, нажмите Enter..."
CLOCK = "2. Часы"
JACKALER = "3. Шакальник"

calc_D = "Введите 1, чтобы сложить два числа, 2 — чтобы из первого вычесть второе, 3 — чтобы умножить, 4 — чтобы разделить, 5 — чтобы получить остаток от деления, 6 — чтобы разделить нацело, 7 — чтобы возвести в степень(возведите на 0.5, чтобы получить корень)"
calc_X = colorama.Style.DIM + "Введите первое число: " + colorama.Style.RESET_ALL
calc_Y = colorama.Style.DIM + "Введите второе число: " + colorama.Style.RESET_ALL
calc_RESULT = "Результат:"
calc_MODE = "Выберите режим калькулятора: "
calc_1 = '1. Простой калькулятор'
calc_2 = "2. Калькулятор квадратных уравнений(=0)"
calc_3 = "3. Массовое сложение"
calc_A = colorama.Style.DIM + "Введите a: " + colorama.Style.RESET_ALL
calc_B = colorama.Style.DIM + "Введите b: " + colorama.Style.RESET_ALL
calc_C = colorama.Style.DIM + "Введите c: " + colorama.Style.RESET_ALL
calc_X1 = "x1="
calc_X2 = "x2="
calc_MASS = colorama.Style.DIM + "Введите количество слагаемых: " + colorama.Style.RESET_ALL
calc_SL = colorama.Style.DIM + "Введите слагаемое: " + colorama.Style.RESET_ALL

easter_1 = "???"
easter_2 = "Зачем тебе это?"
easter_3 = "Это ничем хорошим не закончится..."
easter_4 = "Хорошо, поробуй glitch, но будь осторожен!"
easter_5 = "Я рекомендую просто уйти тебе отсюда, пока не поздно"
easter_6 = "Не зли меня!"
easter_7 = "Я могу тебе помочь, но Он всё слышит..."
easter_8 = "Хм. edit; e,it; ezit; ecit. При выходе не стоит ошибаться, мало ли что..."

glich = "Нажмите CTRL + Z, чтобы завершить сеанс (если Linux)"

ecit_0 = 'Ха-ха! Чтобы выйти, нужно было ввести "exit"! Ха-ха!'
ecit_1 = 'Чтоб выйти, угадай число кое Он задумал от 1 до 12 (с каждым неправильным ответом число обновляется!)'

jackal_ERROR = colorama.Style.BRIGHT + "Не найден файл before.png!"
jackal_INFO = 'Скопируйте png файл в папку system с названием "before.png". Совет — используйте только png файлы, другие типы файлов лучше не переименовывайте.'
jackal_CACH = "Выберите силу сжатия от 2 до 10 включительно: "

d = x = y = ch = ip = a = b = c = cch = 0
